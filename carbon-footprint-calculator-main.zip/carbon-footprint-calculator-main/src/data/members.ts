export const membersData = [
  {
    label: "I live alone",
    value: 14,
  },
  {
    label: "2",
    value: 12,
  },
  {
    label: "3",
    value: 10,
  },
  {
    label: "4",
    value: 8,
  },
  {
    label: "5",
    value: 6,
  },
  {
    label: "6",
    value: 4,
  },
  {
    label: "6+",
    value: 2,
  },
];

export type membersData = typeof membersData;
