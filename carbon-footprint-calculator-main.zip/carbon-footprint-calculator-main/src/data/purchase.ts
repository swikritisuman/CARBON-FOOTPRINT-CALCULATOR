export const purchaseData = [
  {
    label: "More than 7 (Rich AF)",
    value: 10,
  },
  {
    label: "5-6",
    value: 8,
  },
  {
    label: "3-4",
    value: 6,
  },
  {
    label: "Less than 3",
    value: 4,
  },
  {
    label: "I don't have money to purchase anything",
    value: 2,
  },
];

export type purchaseData = typeof purchaseData;
