export const wasteData = [
    {
      label: "4",
      value: 50,
    },
    {
      label: "3",
      value: 40,
    },
    {
      label: "2",
      value: 30,
    },
    {
      label: "1",
      value: 20,
    },
    {
        label: "Less than 1",
        value: 5
    }
  ];
  
  export type wasteData = typeof wasteData;
  