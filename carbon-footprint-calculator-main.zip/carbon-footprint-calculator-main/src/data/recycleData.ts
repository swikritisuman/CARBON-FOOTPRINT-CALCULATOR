export const recycleData = [
  {
    label: "Glass",
    value: -4,
  },
  {
    label: "Plastic",
    value: -4,
  },
  {
    label: "Paper",
    value: -4,
  },
  {
    label: "Aluminium",
    value: -4,
  },
  {
    label: "Steel",
    value: -4,
  },
  {
    label: "Food waste (composting)",
    value: -4,
  },
];

export type recycleData = typeof recycleData;
