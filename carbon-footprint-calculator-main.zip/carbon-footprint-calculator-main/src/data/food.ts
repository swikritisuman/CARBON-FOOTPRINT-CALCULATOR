export const foodData = [
  { label: "Daily", value: 10 },
  { label: "Few times per week", value: 8 },
  { label: "I'm a Vegetarian", value: 4 },
  { label: "I'm a Vegan", value: 2 },
];

export const packagedData = [
  { label: "Mostly prepackaged convenience food", value: 12 },
  { label: "Balance of fresh and convenience food", value: 6 },
  { label: "Only eat fresh, locally grown, or hunted food", value: 2 },
];
