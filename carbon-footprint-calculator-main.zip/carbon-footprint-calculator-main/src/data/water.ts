export const waterData = [
    {
      label: "I don't have a Washing Machine",
      value: 0,
    },
    {
      label: "9 times a week",
      value: 3,
    },
    {
      label: "4 - 8 times a week",
      value: 2,
    },
    {
      label: "1 - 3 times a week",
      value: 1,
    },
  ];
  
  export type waterData = typeof waterData;
  