export const sizeData = [
    {
      label: "Large",
      value: 10,
    },
    {
      label: "Medium",
      value: 7,
    },
    {
      label: "Small",
      value: 4,
    },
    {
      label: "Apartment",
      value: 2,
    },
  ];
  
  export type sizeData = typeof sizeData;
  